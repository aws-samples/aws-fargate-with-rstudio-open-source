#!/usr/bin/env python3
"""
© 2020 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.

This AWS Content is provided subject to the terms of the AWS Customer Agreement
available at http://aws.amazon.com/agreement or other written agreement between
Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

"""

from aws_cdk import core as cdk
from aws_cdk import aws_ec2 as ec2

class VpcStack(cdk.Stack):
        def __init__(self, scope: cdk.Construct, id: str, **kwargs) -> None:
            super().__init__(scope, id, **kwargs)

            instance = self.node.try_get_context("instance")

            if instance is None:
                raise ValueError("Please pass instance to use via context (dev/prod/...)")

            vpc_cidr = self.node.try_get_context("vpc_cidr_range")

            if vpc_cidr is None:
                raise ValueError("Please provide vpc cidr range for the build")

            self.vpc = ec2.Vpc(
                    self, 
                    'our-vpc-' + instance,
                    cidr=vpc_cidr,
                    max_azs=2,
                )